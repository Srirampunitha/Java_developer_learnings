package com.Sriram.Spring.SpringSecurityLearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
