package com.Sriram.s_learning.Sports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
