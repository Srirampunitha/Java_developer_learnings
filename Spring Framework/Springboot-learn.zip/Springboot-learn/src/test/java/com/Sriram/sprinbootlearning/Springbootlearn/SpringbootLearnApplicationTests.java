package com.Sriram.sprinbootlearning.Springbootlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
