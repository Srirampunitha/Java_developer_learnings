package com.Sriram_learning.Crircket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrircketApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrircketApplication.class, args);
	}

}
