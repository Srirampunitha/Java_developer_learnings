package com.Sriram_learning.Crircket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrircketApplicationTests {

	@Test
	void contextLoads() {
	}

}
