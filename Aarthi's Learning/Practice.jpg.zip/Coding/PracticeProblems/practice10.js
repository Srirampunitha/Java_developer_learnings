let res = (4>>4>>4>>5>>2)
console.log(res)