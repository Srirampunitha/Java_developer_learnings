mask = n^m;
