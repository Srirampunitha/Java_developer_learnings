How to find reverse of two number:

Initialize a variable   reverse to 0;

find the remainder of the number by dividing it by 10;

multiply the reverse varaible by 10 and add remainder to it

divide the number by 10

solve this using loops make sure the number is not less than 0.

eg: 

remainder = number % 10;  
reverse = reverse * 10 + remainder;  
number = number/10

20
0*10+0 = 0
2

2
