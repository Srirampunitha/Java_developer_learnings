/*let a = 10;
while(a>5)
{
    console.log("hi", a);
    a--;
}*/

for(let i=1;i<=5;i++)
{
    console.log("hi", i);
    
    for(let j=1;j<5;j++);
    {
        console.log("namjoon", j);
        
    }


}