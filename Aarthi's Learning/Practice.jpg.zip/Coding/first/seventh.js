/*function bts(fav)
{
    return (`I love bts and my favourite is ${fav}`);
}
let fav = "namjoon";
let band = bts(fav);
console.log(band)*/
let add = function(result, a)
{
    let b = result + a;
    return b;
}

/*let a = 1234;
let c = 50;
let remainder, final;
let result = 0;
while(a!=0)
{
 remainder = (a%10);
 result = result + remainder;
 a = parseInt(a/10)

}
console.log(result)
let sum = add(c, result)
console.log(sum);*/

let user = "aarthi";
let job = "IT";
passion = "cafe";
let result = greet(user, job, passion) //calling the function greet
{
console.log(result);
}
console.log("hi")
function greet(u,j,p) //defining the function greet
{
    console.log("hello")
    return (`${u} is now doing a ${j} job but her passion is ${p}`); //returning the function
}

//console.log(result);


