//To find the keys and values in object
let obj = {
    a : 5,
    b: 3,
    c:2
}
let arr = Object.values(obj)
console.log(arr)
let keys = Object.keys(obj)
console.log(keys)
